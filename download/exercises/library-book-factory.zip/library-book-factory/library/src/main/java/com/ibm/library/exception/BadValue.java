package com.ibm.library.exception;

public class BadValue extends Exception {
	
	public BadValue(String msg) {
		super(msg);
	}
}
