package com.ibm.companyemployees.endpoint;

import java.util.Collection;

import com.ibm.companyemployees.model.Employee;

public interface EmployeesEndpoint {

	public Collection<Employee> getEmployees(String companyID);
}
