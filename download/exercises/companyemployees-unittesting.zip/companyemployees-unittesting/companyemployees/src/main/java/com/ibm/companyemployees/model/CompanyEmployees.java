package com.ibm.companyemployees.model;

import java.util.Collection;

public class CompanyEmployees {

	private Company company;
	private Collection<Employee> employees;
	private Boolean empty;
	
	public CompanyEmployees(Company company, Collection<Employee> employees, Boolean empty) {
		super();
		this.company = company;
		this.employees = employees;
		this.empty = empty;
	}

	public CompanyEmployees() {
		super();
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public Collection<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Collection<Employee> employees) {
		this.employees = employees;
	}

	public Boolean getEmpty() {
		return empty;
	}

	public void setEmpty(Boolean empty) {
		this.empty = empty;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((company == null) ? 0 : company.hashCode());
		result = prime * result + ((employees == null) ? 0 : employees.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompanyEmployees other = (CompanyEmployees) obj;
		if (company == null) {
			if (other.company != null)
				return false;
		} else if (!company.equals(other.company))
			return false;
		if (employees == null) {
			if (other.employees != null)
				return false;
		} else if (!employees.equals(other.employees))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CompanyEmployees [company=" + company + ", employees=" + employees + ", empty=" + empty + "]";
	}

}
