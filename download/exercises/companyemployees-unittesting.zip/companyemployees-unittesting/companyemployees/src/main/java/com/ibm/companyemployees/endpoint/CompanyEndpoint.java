package com.ibm.companyemployees.endpoint;

import com.ibm.companyemployees.model.Company;

public interface CompanyEndpoint {

	public Company getCompany(String companyID);
}
