package com.ibm.companyemployees.service;

import java.util.Collection;

import com.ibm.companyemployees.endpoint.EmployeesEndpoint;
import com.ibm.companyemployees.endpoint.CompanyEndpoint;

import com.ibm.companyemployees.model.Employee;

import com.ibm.companyemployees.model.Company;

import com.ibm.companyemployees.model.CompanyEmployees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CompanyEmployeesServiceImpl implements CompanyEmployeesService {

   @Autowired
   private EmployeesEndpoint employeesEndpoint;

   @Autowired
   private CompanyEndpoint companyEndpoint;
	   
   public CompanyEmployees getCompanyEmployees(String companyID) {
		   
	   CompanyEmployees companyEmployees = new CompanyEmployees();
		   
	   Company company = null;
	   Collection<Employee> employees = null;
		   
	   if (companyID != null) {
			   
		   company = this.companyEndpoint.getCompany(companyID);
			   
		   if (company != null) {
			   employees = this.employeesEndpoint.getEmployees(companyID);
				   
			   // setEmpty() is just to help illustrate the unit testing material  
			   if (employees == null) {
				   companyEmployees.setEmpty(true);
			   }
		   }
	   }
		   
	   companyEmployees.setCompany(company);
	   companyEmployees.setEmployees(employees);
		   
	   return companyEmployees;
   }
}