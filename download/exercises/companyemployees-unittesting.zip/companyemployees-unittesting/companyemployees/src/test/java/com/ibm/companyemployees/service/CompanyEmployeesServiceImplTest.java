package com.ibm.companyemployees.service;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import com.ibm.companyemployees.model.Company;
import com.ibm.companyemployees.model.Employee;
import com.ibm.companyemployees.model.CompanyEmployees;
import com.ibm.companyemployees.endpoint.CompanyEndpoint;
import com.ibm.companyemployees.endpoint.EmployeesEndpoint;

class CompanyEmployeesServiceImplTest {

    @Mock 
    private EmployeesEndpoint employeesEndpoint;
    
    @Mock
    private CompanyEndpoint companyEndpoint;

    @InjectMocks  
    private CompanyEmployeesServiceImpl companyEmployeesService;
    
    @BeforeEach
    public void init() {
       MockitoAnnotations.initMocks(this);
    }
    
    @DisplayName("Test getCompanyEmployees with null companyID")
    @Test  
    public void testGetCompanyEmployeesCompanyIDNull() {
    	// Given - set the parameter values and mock the methods for this test case
    	String companyID = null;
    	
    	// Nothing to mock b/c if companyID is null, the endpoint methods aren't called
    	
    	// When - Call the actual method we're testing
    	CompanyEmployees companyEmployees = companyEmployeesService.getCompanyEmployees(companyID);

    	// Then - Check the results of the test (including ensuring that the mocked methods were called - verify)
    	assertNull(companyEmployees.getCompany(), "companyEmployees.getCompany() should be null");
    	
    	// No mockito mocked object methods to verify
    }


    @DisplayName("Test getCompanyEmployees with non-null companyID, non-null company returned from company endpoint and non null employees returned from employees endpoint")
    @Test  
    public void testGetCompanyEmployeesCompanyIDCompanyEmployeesNotNull() {

    	// Given - set the parameter values and mock the methods for this test case
    	String companyID = "someCompanyID";
    	
    	ArrayList<Employee> employees = new ArrayList<Employee>();
    	Employee employee = new Employee("Bob Smith", "123ID");
    	employees.add(employee);
    	when(employeesEndpoint.getEmployees(companyID)).thenReturn(employees);
    	
    	Company company = new Company("someCompany", companyID);
    	when(companyEndpoint.getCompany(companyID)).thenReturn(company);
    	
    	// When - Call the actual method we're testing
    	CompanyEmployees companyEmployees = companyEmployeesService.getCompanyEmployees(companyID);

    	// Then - Check the results of the test (including ensuring that the mocked methods were called - verify)
    	assertNotNull(companyEmployees, "companyEmployees should not be null");
    	assertNotNull(companyEmployees.getCompany(), "companyEmployees.getCompany() should not be null");
    	assertEquals(companyEmployees.getCompany(), company, 
    		" returned company = " + companyEmployees.getCompany() 
    		+ " should be the same as =" + company);
    	
    	verify(employeesEndpoint).getEmployees(companyID);
    	verify(companyEndpoint).getCompany(companyID);
	}
}
