package com.ibm.companyemployees.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

import com.ibm.companyemployees.model.Company;
import com.ibm.companyemployees.model.CompanyEmployees;
import com.ibm.companyemployees.service.CompanyEmployeesService;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class CompanyEmployeesController
{
	private final Logger logger = LoggerFactory.getLogger(CompanyEmployeesController.class);
	
	@Autowired
	private CompanyEmployeesService companyEmployeesService;
	
	public CompanyEmployeesController() {
	}
	
    @RequestMapping(value = "/companyemployees/{companyID}")
	public ResponseEntity<?> getCompanyEmployees(@PathVariable(value="companyID") String companyID) {
    	
    	logger.info("Entered CompanyEmployeesController.getCompanyEmployees().  companyID=" + companyID);
    	
    	CompanyEmployees companyEmployees = this.companyEmployeesService.getCompanyEmployees(companyID);
    	ResponseEntity<CompanyEmployees> responseEntity = new ResponseEntity<CompanyEmployees>(companyEmployees, HttpStatus.OK);
    	
    	logger.info("Leaving CompanyEmployeesController.getCompanyEmployees().  companyID=" + companyID);
    	
		return responseEntity;
	}

}
