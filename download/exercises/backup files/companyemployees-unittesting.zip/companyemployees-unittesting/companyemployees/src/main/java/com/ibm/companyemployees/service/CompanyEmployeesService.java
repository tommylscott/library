package com.ibm.companyemployees.service;

import com.ibm.companyemployees.model.CompanyEmployees;

public interface CompanyEmployeesService {

	public CompanyEmployees getCompanyEmployees(String companyID);
}
