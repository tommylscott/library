package com.ibm.library.model;

public class BookFactory {

}
