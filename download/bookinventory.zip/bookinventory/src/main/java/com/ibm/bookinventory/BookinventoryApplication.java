package com.ibm.bookinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookinventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookinventoryApplication.class, args);
	}

}
