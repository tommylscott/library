package com.ibm.bookinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookinventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
